package com.example.lr49;

public enum ImageLibrary {
    NONE,
    PICASSO,
    GLIDE,
    COIL
}