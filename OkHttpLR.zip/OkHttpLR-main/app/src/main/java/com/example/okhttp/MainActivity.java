package com.example.okhttp;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class MainActivity extends AppCompatActivity {

    private final OkHttpClient client = new OkHttpClient();
    TextView textView1,textView2,textView3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView1 = findViewById(R.id.TV1);
        textView2 = findViewById(R.id.TV2);
        textView3 = findViewById(R.id.TV3);

        new Thread(() -> {
            try {
                String result = testGetRequest(
                        "https://raw.github.com/square/okhttp/master/README.md");
                runOnUiThread(() -> textView1.setText(result));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();

        new Thread(() -> {
            try {
                String result = testPostRequest(
                        "https://api.github.com/markdown/raw");
                runOnUiThread(() -> textView2.setText(result));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();

        testAsyncGetRequest("http://publicobject.com/helloworld.txt");


    }

    private class TestTask extends AsyncTask<String, Void, String>{

        @Override
        protected String doInBackground(String ... strings){
            Request request = new Request.Builder()
                    .url(strings[0])
                    .build();
            try {
                Response response = client.newCall(request).execute();
                Log.e("code", "" + response.code() + "|" + response.message());
                return response.body().string();
            }catch (IOException e){
                throw new RuntimeException(e);
            }
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            textView1.setText(s);
        }


    }

    public String testGetRequest(String urlString) throws IOException {
        Request request = new Request.Builder()
                .url(urlString)
                .build();
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful())
                throw new IOException("Unexpected code " + response);
            return response.body().string();
        }
    }

    public static final MediaType MEDIA_TYPE_MARKDOWN
            = MediaType.get("text/x-markdown; charset=utf-8");

    public String testPostRequest(String urlString) throws IOException {
        String postBody = ""
                + "Releases\n"
                + "--------\n"
                + "\n"
                + " * _1.0_ May 6, 2013\n"
                + " * _1.1_ June 15, 2013\n"
                + " * _1.2_ August 11, 2013\n";

        Request request = new Request.Builder()
                .url(urlString)
                .post(RequestBody.create(MEDIA_TYPE_MARKDOWN, postBody))
                .build();
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful())
                throw new IOException("Unexpected code " + response);
            return response.body().string();
        }
    }


    public void testAsyncGetRequest(String url) {
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> {
                    textView3.setText("Error: " + e.getMessage());
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try (ResponseBody responseBody = response.body()) {
                    if (!response.isSuccessful()) {
                        runOnUiThread(() -> {
                            textView3.setText("Unexpected code " + response);
                        });
                        return;
                    }

                    Headers responseHeaders = response.headers();
                    for (int i = 0; i < responseHeaders.size(); i++) {
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }

                    final String responseData = responseBody.string();
                    runOnUiThread(() -> {
                        textView3.setText(responseData);
                    });
                }
            }
        });
    }
}