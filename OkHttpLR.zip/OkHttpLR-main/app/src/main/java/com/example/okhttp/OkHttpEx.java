package com.example.okhttp;

import android.app.Activity;
import android.content.Context;
import android.widget.TextView;

import okhttp3.*;
import java.io.IOException;


public class OkHttpEx {
    private final OkHttpClient client = new OkHttpClient();
    private Context context;
    private TextView textView;

    public OkHttpEx(Context context, TextView textView) {
        this.context = context;
        this.textView = textView;
    }

    public String testGetRequest(String urlString) throws IOException {
        Request request = new Request.Builder()
                .url(urlString)
                .build();
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful())
                throw new IOException("Unexpected code " + response);
            return response.body().string();
        }
    }


    public static final MediaType MEDIA_TYPE_MARKDOWN
            = MediaType.get("text/x-markdown; charset=utf-8");

    public String testPostRequest(String urlString) throws IOException {
        String postBody = ""
                + "Releases\n"
                + "--------\n"
                + "\n"
                + " * _1.0_ May 6, 2013\n"
                + " * _1.1_ June 15, 2013\n"
                + " * _1.2_ August 11, 2013\n";

        Request request = new Request.Builder()
                .url(urlString)
                .post(RequestBody.create(MEDIA_TYPE_MARKDOWN, postBody))
                .build();
        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful())
                throw new IOException("Unexpected code " + response);
            return response.body().string();
        }
    }


    public void testAsyncGetRequest(String url) {
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                ((Activity)context).runOnUiThread(() -> {
                    textView.setText("Error: " + e.getMessage());
                });
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try (ResponseBody responseBody = response.body()) {
                    if (!response.isSuccessful()) {
                        ((Activity)context).runOnUiThread(() -> {
                            textView.setText("Unexpected code " + response);
                        });
                        return;
                    }

                    Headers responseHeaders = response.headers();
                    for (int i = 0; i < responseHeaders.size(); i++) {
                        System.out.println(responseHeaders.name(i) + ": " + responseHeaders.value(i));
                    }

                    final String responseData = responseBody.string();
                    ((Activity)context).runOnUiThread(() -> {
                        textView.setText(responseData);
                    });
                }
            }
        });
    }
}
